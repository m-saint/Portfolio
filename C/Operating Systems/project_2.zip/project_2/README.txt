Myles St. Jean - Project 2

Problem 1 Brief Overview:
Shoes line up with their type, and are allowed onto the stage by shoes of another type once that type is done. I split things up into three functions by shoe type, so each type could signal the other types. This just kept things more organized in my brain. It doesn't get stuck and no type starves.

Problem 2 Brief Overview:
Players generate their stance cards when they're first in line for their team. They then reserve the spots they need before doing them on the mat, it's like they're planning with each other how they can all make it through. After I came up with a working solution that didn't deadlock, I moved on to slight modifications to get a good balance between the number of players on the mat at the same time and giving all players a fair chance to progress.