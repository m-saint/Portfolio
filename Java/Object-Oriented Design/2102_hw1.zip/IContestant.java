
public interface IContestant {}
