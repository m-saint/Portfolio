
public interface IResult {
	
	 boolean isValid();
	 
	 IContestant getWinner();
}
