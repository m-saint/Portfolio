
public interface IWinner {
	
	boolean isWinner(IContestant checkedCont);
	
}
